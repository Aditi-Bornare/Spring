package com.user.service;

import com.user.beans.User;

public interface UserService {

    public User getUser(Long id);
}
